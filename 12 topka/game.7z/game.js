// Creating variables
var gamerX = 0,gamerY = 0;
var notaX =  800, notaY = 300;

function update(){
    notaX = notaX - 6;
    if(mouseY<300){
        gamerY=0;
    }
     if(mouseY>300){
        gamerY=300;
    }
    if(notaX<0){
        notaX=800;
        if(notaY<1){
            notaY=300;
        }
        if(notaY>299){
            notaY =  0;
    }
    }
}

function draw() {
    // This is how you draw a rectangle
    context.fillRect(gamerX,gamerY,30, 300);
    context.fillRect(notaX,notaY,30,300)
};

function keyup(key) {
    gamerY = 0;
    
    // Show the pressed keycode in the console
    console.log("Pressed", key);
};

function mouseup() {
    gamerY = 300;
    // Show coordinates of mouse on click
    console.log("Mouse clicked at", mouseX, mouseY);
    
};
